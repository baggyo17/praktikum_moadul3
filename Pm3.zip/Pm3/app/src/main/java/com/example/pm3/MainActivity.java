package com.example.pm3;

import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements TextWatcher {
    AutoCompleteTextView ac;
    public String[] stringdatafak = {"Teknik Informatika", "Sistem Informasi", "Desain Komunikasi Visual", "Manajemen Informatika", "Teknik Sipil"};
    EditText lv;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ac = findViewById(R.id.dataautocomplete);
        ac.addTextChangedListener(this);
        ac.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, stringdatafak));
    }

    public void pilihfakultas(View v) {
        lv = findViewById(R.id.datalistview);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Data Program Studi Fakultas Ilmu Komputer");
        builder.setItems(stringdatafak, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int item) {
                lv.setText(stringdatafak[item]);
                dialog.dismiss();
                // Mengubah warna latar belakang saat salah satu data program studi dipilih
                getWindow().getDecorView().setBackgroundColor(getColorFromProgramStudy(stringdatafak[item]));
            }
        }).show();
    }

    private int getColorFromProgramStudy(String programStudy) {
        // Mengembalikan warna berdasarkan program studi yang dipilih
        switch (programStudy) {
            case "Teknik Informatika":
                return Color.RED;
            case "Sistem Informasi":
                return Color.BLUE;
            case "Desain Komunikasi Visual":
                return Color.GREEN;
            case "Manajemen Informatika":
                return Color.YELLOW;
            case "Teknik Sipil":
                return Color.CYAN;
            default:
                return Color.WHITE;
        }
    }

    public void onTextChanged(CharSequence s, int start, int before, int count) { }

    public void beforeTextChanged(CharSequence s, int start, int count, int after) { }

    public void afterTextChanged(Editable s) { }

    @Override
    protected void onPause() {
        super.onPause();
        getWindow().getDecorView().setBackgroundColor(Color.WHITE);
    }
}
